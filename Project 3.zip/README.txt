README.txt

To run this program:
1.  make Boomer
2.  ./Boomer
3.  Follow the on-screen instructions!

Read Ballew
Thien-An Vu
CSCE 2100.001
Professor Helsing