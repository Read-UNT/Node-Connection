#ifndef BOOMER_H
#define BOOMER_H

struct edge{
        int valueOne;
        int valueTwo;
        int time;
    } tempEdge;

struct path{
        int start;
        int end;
    } tempPath;

#endif